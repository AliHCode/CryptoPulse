import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Coin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  fully_diluted_valuation: number | null;
  total_volume: number;
  high_24h: number;
  low_24h: number;
  price_change_24h: number;
  price_change_percentage_24h: number;
  market_cap_change_24h: number;
  market_cap_change_percentage_24h: number;
  circulating_supply: number;
  total_supply: number | null;
  max_supply: number | null;
  ath: number;
  ath_change_percentage: number;
  ath_date: string;
  atl: number;
  atl_change_percentage: number;
  atl_date: string;
  roi: null | {
    times: number;
    currency: string;
    percentage: number;
  };
  last_updated: string;
  sparkline_in_7d?: {
    price: number[];
  };
}

export interface PortfolioItem {
  coinId: string;
  amount: number;
  buyPrice: number; // Average buy price
}

export interface PriceAlert {
  id: string;
  coinId: string;
  targetPrice: number;
  condition: 'above' | 'below';
  isActive: boolean;
}

interface CryptoState {
  coins: Coin[];
  portfolio: PortfolioItem[];
  alerts: PriceAlert[];
  isLoading: boolean;
  error: string | null;
  
  setCoins: (coins: Coin[]) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  
  addToPortfolio: (item: PortfolioItem) => void;
  removeFromPortfolio: (coinId: string) => void;
  updatePortfolioItem: (coinId: string, amount: number) => void;
  
  addAlert: (alert: PriceAlert) => void;
  removeAlert: (id: string) => void;
  toggleAlert: (id: string) => void;
}

export const useCryptoStore = create<CryptoState>()(
  persist(
    (set) => ({
      coins: [],
      portfolio: [],
      alerts: [],
      isLoading: false,
      error: null,

      setCoins: (coins) => set({ coins }),
      setLoading: (isLoading) => set({ isLoading }),
      setError: (error) => set({ error }),

      addToPortfolio: (item) =>
        set((state) => {
          const existing = state.portfolio.find((p) => p.coinId === item.coinId);
          if (existing) {
            // Update existing holding (simple average cost basis logic could go here, but keeping it simple for now)
            return {
              portfolio: state.portfolio.map((p) =>
                p.coinId === item.coinId
                  ? { ...p, amount: p.amount + item.amount }
                  : p
              ),
            };
          }
          return { portfolio: [...state.portfolio, item] };
        }),

      removeFromPortfolio: (coinId) =>
        set((state) => ({
          portfolio: state.portfolio.filter((p) => p.coinId !== coinId),
        })),

      updatePortfolioItem: (coinId, amount) =>
        set((state) => ({
          portfolio: state.portfolio.map((p) =>
            p.coinId === coinId ? { ...p, amount } : p
          ),
        })),

      addAlert: (alert) =>
        set((state) => ({ alerts: [...state.alerts, alert] })),

      removeAlert: (id) =>
        set((state) => ({
          alerts: state.alerts.filter((a) => a.id !== id),
        })),

      toggleAlert: (id) =>
        set((state) => ({
          alerts: state.alerts.map((a) =>
            a.id === id ? { ...a, isActive: !a.isActive } : a
          ),
        })),
    }),
    {
      name: 'crypto-storage',
      partialize: (state) => ({
        portfolio: state.portfolio,
        alerts: state.alerts,
      }), // Only persist user data, not the API cache
    }
  )
);
