import axios from 'axios';
import { Coin } from '../store/cryptoStore';

const COINGECKO_API = 'https://api.coingecko.com/api/v3';

// Simple cache to prevent hitting rate limits too hard in dev
let cache: { data: Coin[]; timestamp: number } | null = null;
const CACHE_DURATION = 60 * 1000; // 1 minute

export const fetchCoins = async (): Promise<Coin[]> => {
  if (cache && Date.now() - cache.timestamp < CACHE_DURATION) {
    return cache.data;
  }

  try {
    const response = await axios.get(`${COINGECKO_API}/coins/markets`, {
      params: {
        vs_currency: 'usd',
        order: 'market_cap_desc',
        per_page: 100,
        page: 1,
        sparkline: true,
        price_change_percentage: '24h,7d',
      },
    });
    
    cache = { data: response.data, timestamp: Date.now() };
    return response.data;
  } catch (error) {
    console.error('Error fetching coins:', error);
    throw error;
  }
};

export const fetchCoinHistory = async (coinId: string, days: number = 7) => {
  try {
    const response = await axios.get(`${COINGECKO_API}/coins/${coinId}/market_chart`, {
      params: {
        vs_currency: 'usd',
        days: days,
      },
    });
    return response.data.prices; // Array of [timestamp, price]
  } catch (error) {
    console.error('Error fetching coin history:', error);
    throw error;
  }
};
