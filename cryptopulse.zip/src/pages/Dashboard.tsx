import React, { useState } from 'react';
import { useCryptoStore } from '../store/cryptoStore';
import { Search, ArrowUpRight, ArrowDownRight, Terminal, Activity } from 'lucide-react';
import { Link } from 'react-router-dom';
import { clsx } from 'clsx';
import { analyzeMarket } from '../services/gemini';
import { useToastStore } from '../components/Toast';

export default function Dashboard() {
  const { coins, isLoading } = useCryptoStore();
  const [search, setSearch] = useState('');
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const { addToast } = useToastStore();

  const handleAnalyze = async () => {
    setAnalyzing(true);
    try {
      const result = await analyzeMarket(coins);
      setAiAnalysis(result);
    } catch (e) {
      console.error(e);
      addToast({
        title: 'ANALYSIS FAILED',
        message: 'API CONNECTION ERROR',
        type: 'error'
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const filteredCoins = coins.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.symbol.toLowerCase().includes(search.toLowerCase())
  );

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 6 }).format(val);

  const formatPercent = (val: number) => 
    `${val > 0 ? '+' : ''}${val.toFixed(2)}%`;

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white font-mono tracking-tight uppercase flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-500" />
            Market Overview
          </h1>
          <p className="text-xs text-slate-500 font-mono mt-1">GLOBAL CRYPTOCURRENCY INDEX</p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="SEARCH TICKER..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-48 bg-black border border-slate-700 text-white pl-9 pr-4 py-1.5 text-xs font-mono focus:outline-none focus:border-amber-500 transition-colors placeholder:text-slate-700 uppercase"
            />
          </div>
          <button 
            onClick={handleAnalyze}
            disabled={analyzing || coins.length === 0}
            className="flex items-center gap-2 px-4 py-1.5 bg-slate-900 border border-slate-700 hover:border-amber-500 text-amber-500 text-xs font-bold font-mono uppercase transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {analyzing ? (
              <span className="animate-pulse">PROCESSING...</span>
            ) : (
              <>
                <Terminal className="w-3 h-3" />
                Run Analysis
              </>
            )}
          </button>
        </div>
      </div>

      {/* AI Analysis Terminal */}
      {aiAnalysis && (
        <div className="bg-black border border-amber-500/30 p-4 font-mono text-sm relative">
          <div className="absolute top-0 left-0 px-2 py-0.5 bg-amber-500/20 text-amber-500 text-[10px] font-bold uppercase border-b border-r border-amber-500/30">
            Gemini Intelligence
          </div>
          <div className="mt-4 grid md:grid-cols-4 gap-6">
            <div className="border-r border-slate-800 pr-6">
              <p className="text-xs text-slate-500 uppercase mb-1">Sentiment</p>
              <p className={clsx(
                "text-xl font-bold uppercase",
                aiAnalysis.sentiment === 'Bullish' ? 'text-emerald-500' : 
                aiAnalysis.sentiment === 'Bearish' ? 'text-rose-500' : 'text-amber-500'
              )}>{aiAnalysis.sentiment}</p>
            </div>
            <div className="md:col-span-3">
              <p className="text-xs text-slate-500 uppercase mb-2">Key Takeaways</p>
              <ul className="space-y-1">
                {aiAnalysis.takeaways?.map((t: string, i: number) => (
                  <li key={i} className="text-slate-300 flex items-start gap-2">
                    <span className="text-amber-500">&gt;</span>
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Data Grid */}
      <div className="border border-slate-800 bg-black">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-mono text-sm">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/50 text-[10px] uppercase tracking-wider text-slate-500">
                <th className="p-3 pl-4 font-normal">Asset</th>
                <th className="p-3 text-right font-normal">Price (USD)</th>
                <th className="p-3 text-right font-normal">24h %</th>
                <th className="p-3 text-right font-normal hidden md:table-cell">Market Cap</th>
                <th className="p-3 text-right font-normal hidden lg:table-cell">Vol (24h)</th>
                <th className="p-3 text-right font-normal w-32">Trend (7d)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {isLoading && coins.length === 0 ? (
                [...Array(10)].map((_, i) => (
                  <tr key={i}>
                    <td colSpan={6} className="p-3 text-center text-slate-600 text-xs animate-pulse">LOADING DATA STREAM...</td>
                  </tr>
                ))
              ) : (
                filteredCoins.map((coin) => (
                  <tr key={coin.id} className="group hover:bg-slate-900 transition-colors">
                    <td className="p-3 pl-4">
                      <Link to={`/coin/${coin.id}`} className="flex items-center gap-3">
                        <span className="font-bold text-amber-500 w-8 text-right">{coin.market_cap_rank}</span>
                        <div>
                          <div className="font-bold text-slate-200 group-hover:text-white group-hover:underline decoration-amber-500 underline-offset-2">{coin.symbol.toUpperCase()}</div>
                        </div>
                      </Link>
                    </td>
                    <td className="p-3 text-right text-slate-200">
                      {formatCurrency(coin.current_price)}
                    </td>
                    <td className={clsx(
                      "p-3 text-right font-bold",
                      coin.price_change_percentage_24h >= 0 ? "text-emerald-500" : "text-rose-500"
                    )}>
                      {formatPercent(coin.price_change_percentage_24h)}
                    </td>
                    <td className="p-3 text-right text-slate-400 hidden md:table-cell">
                      {(coin.market_cap / 1e9).toFixed(2)}B
                    </td>
                    <td className="p-3 text-right text-slate-400 hidden lg:table-cell">
                      {(coin.total_volume / 1e6).toFixed(2)}M
                    </td>
                    <td className="p-3 text-right">
                      <div className="h-6 w-24 ml-auto">
                         <svg className="w-full h-full overflow-visible" viewBox="0 0 100 40" preserveAspectRatio="none">
                            <polyline
                              fill="none"
                              stroke={coin.price_change_percentage_24h >= 0 ? "#10b981" : "#f43f5e"}
                              strokeWidth="1.5"
                              points={coin.sparkline_in_7d?.price.map((p, i, arr) => {
                                const min = Math.min(...arr);
                                const max = Math.max(...arr);
                                const x = (i / (arr.length - 1)) * 100;
                                const y = 40 - ((p - min) / (max - min)) * 40;
                                return `${x},${y}`;
                              }).join(' ')}
                            />
                         </svg>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
