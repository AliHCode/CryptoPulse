import React, { useState } from 'react';
import { useCryptoStore } from '../store/cryptoStore';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Trash2, Edit2, TrendingUp, Wallet, Terminal } from 'lucide-react';
import { clsx } from 'clsx';
import { analyzePortfolio } from '../services/gemini';
import { useToastStore } from '../components/Toast';

export default function Portfolio() {
  const { portfolio, coins, removeFromPortfolio, updatePortfolioItem } = useCryptoStore();
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const { addToast } = useToastStore();

  // Calculate portfolio stats
  const portfolioData = portfolio.map(item => {
    const coin = coins.find(c => c.id === item.coinId);
    if (!coin) return null;
    return {
      ...item,
      name: coin.name,
      symbol: coin.symbol,
      currentPrice: coin.current_price,
      value: item.amount * coin.current_price,
      allocation: 0 // calculated below
    };
  }).filter(Boolean) as any[];

  const totalValue = portfolioData.reduce((acc, item) => acc + item.value, 0);
  
  // Add allocation
  portfolioData.forEach(item => {
    item.allocation = (item.value / totalValue) * 100;
  });

  const COLORS = ['#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#8b5cf6', '#64748b'];

  const handleAnalyze = async () => {
    setAnalyzing(true);
    try {
      const result = await analyzePortfolio(portfolio, coins);
      setAiAnalysis(result);
    } catch (e) {
      console.error(e);
      addToast({
        title: 'ANALYSIS FAILED',
        message: 'API CONNECTION ERROR',
        type: 'error'
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSaveEdit = (coinId: string) => {
    const amount = parseFloat(editAmount);
    if (!isNaN(amount) && amount >= 0) {
      updatePortfolioItem(coinId, amount);
    }
    setIsEditing(null);
  };

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  if (portfolio.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center font-mono">
        <div className="w-16 h-16 border border-slate-800 flex items-center justify-center mb-6">
          <Wallet className="w-8 h-8 text-slate-600" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2 uppercase">Portfolio Empty</h2>
        <p className="text-slate-500 max-w-md mb-8 text-xs">NO ASSETS DETECTED. INITIATE POSITIONS VIA MARKET DATA.</p>
        <a href="/" className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase text-xs transition-colors">
          Initialize Portfolio
        </a>
      </div>
    );
  }

  return (
    <div className="space-y-6 font-mono">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight uppercase flex items-center gap-2">
            <Wallet className="w-5 h-5 text-amber-500" />
            Portfolio Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">ASSET ALLOCATION & PERFORMANCE METRICS</p>
        </div>
        <button 
          onClick={handleAnalyze}
          disabled={analyzing}
          className="flex items-center gap-2 px-4 py-1.5 bg-slate-900 border border-slate-700 hover:border-amber-500 text-amber-500 text-xs font-bold uppercase transition-all disabled:opacity-50"
        >
          {analyzing ? <span className="animate-pulse">PROCESSING...</span> : <Terminal className="w-3 h-3" />}
          Run Audit
        </button>
      </div>

      {/* AI Analysis Terminal */}
      {aiAnalysis && (
        <div className="bg-black border border-amber-500/30 p-4 font-mono text-sm relative">
          <div className="absolute top-0 left-0 px-2 py-0.5 bg-amber-500/20 text-amber-500 text-[10px] font-bold uppercase border-b border-r border-amber-500/30">
            Gemini Intelligence
          </div>
          <div className="mt-4 grid md:grid-cols-3 gap-6">
            <div className="border-r border-slate-800 pr-6">
              <p className="text-xs text-slate-500 uppercase mb-1">Risk Profile</p>
              <p className={clsx(
                "text-xl font-bold uppercase",
                aiAnalysis.riskLevel === 'High' ? 'text-rose-500' : 
                aiAnalysis.riskLevel === 'Low' ? 'text-emerald-500' : 'text-amber-500'
              )}>{aiAnalysis.riskLevel}</p>
            </div>
            <div className="md:col-span-2 space-y-4">
              <div>
                <p className="text-xs text-slate-500 uppercase mb-1">Strategic Advice</p>
                <p className="text-slate-300 text-xs leading-relaxed border-l-2 border-amber-500 pl-3">{aiAnalysis.advice}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase mb-1">Diversification</p>
                <p className="text-slate-300 text-xs leading-relaxed border-l-2 border-blue-500 pl-3">{aiAnalysis.diversification}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left Col: Stats & List */}
        <div className="lg:col-span-2 space-y-6">
          {/* Total Balance Card */}
          <div className="bg-black border border-slate-800 p-6 relative overflow-hidden">
            <div className="relative z-10">
              <p className="text-slate-500 text-xs uppercase mb-1">Total Net Worth</p>
              <div className="text-4xl font-bold text-white tracking-tight">
                {formatCurrency(totalValue)}
              </div>
              <div className="mt-4 flex items-center gap-2 text-emerald-500 text-xs font-bold uppercase">
                <div className="w-2 h-2 bg-emerald-500 animate-pulse" />
                <span>Portfolio Active</span>
              </div>
            </div>
          </div>

          {/* Holdings List */}
          <div className="border border-slate-800 bg-black">
            <div className="p-3 border-b border-slate-800 bg-slate-900/50">
              <h3 className="text-xs font-bold text-slate-400 uppercase">Asset Breakdown</h3>
            </div>
            <div className="divide-y divide-slate-800">
              {portfolioData.map((item) => (
                <div key={item.coinId} className="p-4 flex items-center justify-between hover:bg-slate-900 transition-colors group">
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 flex items-center justify-center text-sm font-bold text-amber-500 border border-slate-800 bg-slate-900">
                      {item.symbol[0].toUpperCase()}
                    </div>
                    <div>
                      <div className="font-bold text-white text-sm">{item.name}</div>
                      <div className="text-xs text-slate-500">{item.amount} {item.symbol.toUpperCase()}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-8">
                    <div className="text-right">
                      <div className="font-bold text-white text-sm">{formatCurrency(item.value)}</div>
                      <div className="text-xs text-slate-500">{formatCurrency(item.currentPrice)}</div>
                    </div>
                    
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      {isEditing === item.coinId ? (
                        <div className="flex items-center gap-2">
                          <input 
                            type="number" 
                            value={editAmount} 
                            onChange={(e) => setEditAmount(e.target.value)}
                            className="w-20 bg-black border border-amber-500 px-2 py-1 text-xs text-white focus:outline-none"
                            autoFocus
                          />
                          <button onClick={() => handleSaveEdit(item.coinId)} className="text-emerald-500 hover:text-emerald-400 text-xs font-bold uppercase">SAVE</button>
                        </div>
                      ) : (
                        <button 
                          onClick={() => {
                            setIsEditing(item.coinId);
                            setEditAmount(item.amount.toString());
                          }}
                          className="p-1.5 text-slate-500 hover:text-amber-500 hover:bg-slate-800 transition-colors"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                      )}
                      <button 
                        onClick={() => removeFromPortfolio(item.coinId)}
                        className="p-1.5 text-slate-500 hover:text-rose-500 hover:bg-slate-800 transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Chart */}
        <div className="space-y-6">
          <div className="bg-black border border-slate-800 p-6 h-96">
            <h3 className="text-xs font-bold text-slate-400 uppercase mb-6">Allocation Distribution</h3>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={portfolioData}
                  cx="50%"
                  cy="45%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                  stroke="none"
                >
                  {portfolioData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#000', borderColor: '#334155', borderRadius: '0', color: '#fff', fontFamily: 'JetBrains Mono' }}
                  formatter={(val: number) => formatCurrency(val)}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-1">
              {portfolioData.map((item, index) => (
                <div key={item.coinId} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                    <span className="text-slate-300">{item.name}</span>
                  </div>
                  <span className="text-slate-400">{item.allocation.toFixed(1)}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
