import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCryptoStore } from '../store/cryptoStore';
import { fetchCoinHistory } from '../services/api';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { ArrowLeft, Plus, Bell, TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { clsx } from 'clsx';
import { format } from 'date-fns';

export default function CoinDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { coins, addToPortfolio, addAlert } = useCryptoStore();
  const coin = coins.find(c => c.id === id);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeframe, setTimeframe] = useState(7);

  useEffect(() => {
    if (!id) return;
    const loadHistory = async () => {
      setLoading(true);
      try {
        const data = await fetchCoinHistory(id, timeframe);
        setHistory(data.map((item: any[]) => ({
          date: item[0],
          price: item[1]
        })));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    loadHistory();
  }, [id, timeframe]);

  if (!coin) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-slate-500 font-mono">
        <p>ASSET_NOT_FOUND_OR_LOADING</p>
        <button onClick={() => navigate('/')} className="mt-4 text-amber-500 hover:underline">
          RETURN_TO_DASHBOARD
        </button>
      </div>
    );
  }

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  return (
    <div className="space-y-6 font-mono">
      <button 
        onClick={() => navigate('/')}
        className="flex items-center gap-2 text-slate-500 hover:text-amber-500 transition-colors text-xs uppercase"
      >
        <ArrowLeft className="w-3 h-3" /> Back to Index
      </button>

      {/* Header Section */}
      <div className="border border-slate-800 bg-black p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <div className="flex items-baseline gap-3">
              <h1 className="text-3xl font-bold text-white tracking-tight uppercase">{coin.name}</h1>
              <span className="text-xl text-amber-500">{coin.symbol.toUpperCase()}</span>
            </div>
            <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
              <span>RANK: #{coin.market_cap_rank}</span>
              <span>|</span>
              <span>UPDATED: {new Date(coin.last_updated).toLocaleTimeString()}</span>
            </div>
          </div>

          <div className="flex gap-2">
            <button 
              onClick={() => addToPortfolio({ coinId: coin.id, amount: 0, buyPrice: coin.current_price })}
              className="px-4 py-2 bg-slate-900 border border-slate-700 hover:border-amber-500 text-slate-200 hover:text-amber-500 text-xs font-bold uppercase transition-all"
            >
              + Add Position
            </button>
            <button 
              onClick={() => addAlert({ 
                id: crypto.randomUUID(), 
                coinId: coin.id, 
                targetPrice: coin.current_price * 1.05, 
                condition: 'above', 
                isActive: true 
              })}
              className="px-4 py-2 bg-slate-900 border border-slate-700 hover:border-amber-500 text-slate-200 hover:text-amber-500 text-xs font-bold uppercase transition-all"
            >
              + Set Alert
            </button>
          </div>
        </div>

        {/* Key Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mt-8 pt-8 border-t border-slate-800">
          <div>
            <p className="text-xs text-slate-500 uppercase mb-1">Price (USD)</p>
            <div className="text-2xl font-bold text-white">{formatCurrency(coin.current_price)}</div>
            <div className={clsx(
              "text-xs mt-1 flex items-center gap-1",
              coin.price_change_percentage_24h >= 0 ? "text-emerald-500" : "text-rose-500"
            )}>
              {coin.price_change_percentage_24h >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
            </div>
          </div>

          <div>
            <p className="text-xs text-slate-500 uppercase mb-1">Market Cap</p>
            <div className="text-xl font-bold text-slate-200">${(coin.market_cap / 1e9).toFixed(2)}B</div>
          </div>

          <div>
            <p className="text-xs text-slate-500 uppercase mb-1">Volume (24h)</p>
            <div className="text-xl font-bold text-slate-200">${(coin.total_volume / 1e6).toFixed(2)}M</div>
          </div>

          <div>
            <p className="text-xs text-slate-500 uppercase mb-1">All Time High</p>
            <div className="text-xl font-bold text-slate-200">{formatCurrency(coin.ath)}</div>
            <p className="text-[10px] text-slate-600 mt-1">
              {new Date(coin.ath_date).toLocaleDateString()}
            </p>
          </div>
        </div>
      </div>

      {/* Chart Section */}
      <div className="border border-slate-800 bg-black p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-sm font-bold text-amber-500 uppercase flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Price Action
          </h2>
          <div className="flex border border-slate-800">
            {[1, 7, 30, 90].map((d) => (
              <button
                key={d}
                onClick={() => setTimeframe(d)}
                className={clsx(
                  "px-3 py-1 text-xs font-bold transition-all border-r border-slate-800 last:border-r-0",
                  timeframe === d ? "bg-amber-500 text-black" : "text-slate-500 hover:text-white hover:bg-slate-900"
                )}
              >
                {d === 1 ? '24H' : `${d}D`}
              </button>
            ))}
          </div>
        </div>
        
        <div className="h-[400px] w-full">
          {loading ? (
            <div className="h-full w-full flex items-center justify-center text-slate-500">
              <span className="animate-pulse">LOADING_CHART_DATA...</span>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history}>
                <defs>
                  <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={(ts) => {
                    const date = new Date(ts);
                    return timeframe === 1 ? format(date, 'HH:mm') : format(date, 'MMM d');
                  }}
                  stroke="#4b5563"
                  tick={{ fontSize: 10, fontFamily: 'JetBrains Mono' }}
                  tickMargin={10}
                />
                <YAxis 
                  domain={['auto', 'auto']}
                  tickFormatter={(val) => `$${val.toLocaleString()}`}
                  stroke="#4b5563"
                  tick={{ fontSize: 10, fontFamily: 'JetBrains Mono' }}
                  width={60}
                  orientation="right"
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#000', borderColor: '#334155', borderRadius: '0', color: '#fff', fontFamily: 'JetBrains Mono' }}
                  itemStyle={{ color: '#f59e0b' }}
                  labelFormatter={(ts) => format(new Date(ts), 'yyyy-MM-dd HH:mm:ss')}
                  formatter={(val: number) => [formatCurrency(val), 'Price']}
                  cursor={{ stroke: '#f59e0b', strokeWidth: 1, strokeDasharray: '4 4' }}
                />
                <Area 
                  type="step" 
                  dataKey="price" 
                  stroke="#f59e0b" 
                  strokeWidth={1}
                  fillOpacity={1} 
                  fill="url(#colorPrice)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}
