import React, { useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, PieChart, Bell, TrendingUp, Menu, X } from 'lucide-react';
import { clsx } from 'clsx';
import { useCryptoStore } from '../store/cryptoStore';
import { fetchCoins } from '../services/api';
import { ToastContainer, useToastStore } from './Toast';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);
  const { setCoins, setLoading, coins, alerts } = useCryptoStore();
  const { addToast } = useToastStore();
  const location = useLocation();

  useEffect(() => {
    const loadCoins = async (showLoading = false) => {
      if (showLoading) setLoading(true);
      try {
        const data = await fetchCoins();
        setCoins(data);
        
        // Check alerts immediately after fetch
        const currentAlerts = useCryptoStore.getState().alerts;
        currentAlerts.forEach(alert => {
           if (!alert.isActive) return;
           const coin = data.find((c: any) => c.id === alert.coinId);
           if (!coin) return;
           
           const isTriggered = alert.condition === 'above' 
             ? coin.current_price > alert.targetPrice 
             : coin.current_price < alert.targetPrice;

           if (isTriggered) {
             // Check if we already notified recently? 
             // For demo, we'll just notify.
             // To prevent spam, we could toggle isActive to false automatically?
             // Let's do that for the demo.
             useCryptoStore.getState().toggleAlert(alert.id); // Turn off after triggering
             
             addToast({
               title: 'Price Alert Triggered!',
               message: `${coin.name} is now ${alert.condition} $${alert.targetPrice}`,
               type: 'success'
             });
           }
        });

      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    
    // Initial load - show loading if we don't have data
    loadCoins(coins.length === 0);

    // Poll every 60s - silent update
    const interval = setInterval(() => loadCoins(false), 60000);
    return () => clearInterval(interval);
  }, [setCoins, setLoading, addToast]); // coins.length is intentionally omitted

  const navItems = [
    { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/portfolio', icon: PieChart, label: 'Portfolio' },
    { to: '/alerts', icon: Bell, label: 'Alerts' },
    // { to: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500/30">
      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
          <TrendingUp className="w-6 h-6 text-indigo-500" />
          <span>CryptoPulse</span>
        </div>
        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-slate-800 rounded-lg">
          {isSidebarOpen ? <X /> : <Menu />}
        </button>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={clsx(
            "fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 border-r border-slate-800 transform transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:h-screen",
            isSidebarOpen ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <div className="h-full flex flex-col">
            <div className="p-6 flex items-center gap-3 border-b border-slate-800/50">
              <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl tracking-tight">CryptoPulse</span>
            </div>

            <nav className="flex-1 p-4 space-y-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  onClick={() => setIsSidebarOpen(false)}
                  className={({ isActive }) =>
                    clsx(
                      "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium text-sm",
                      isActive
                        ? "bg-indigo-500/10 text-indigo-400 shadow-sm border border-indigo-500/20"
                        : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
                    )
                  }
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </NavLink>
              ))}
            </nav>

            <div className="p-4 border-t border-slate-800/50">
              <div className="bg-slate-800/50 rounded-xl p-4">
                <p className="text-xs text-slate-500 font-mono mb-2">MARKET STATUS</p>
                <div className="flex items-center gap-2 text-emerald-400 text-sm font-medium">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  Live Updates
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0 lg:h-screen lg:overflow-y-auto">
          <div className="max-w-7xl mx-auto p-4 lg:p-8">
            {children}
          </div>
        </main>

        {/* Overlay for mobile sidebar */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-30 lg:hidden backdrop-blur-sm"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
      </div>
      <ToastContainer />
    </div>
  );
}
